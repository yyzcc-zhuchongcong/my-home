"use strict";

/* ============================================================
 * media-bridge.js — 系统媒体通知桥接模块
 *
 * 目标：让顶部歌名信息条随「系统播放器 / 第三方音乐应用」的
 *       播放内容自动变化，并处理 Android 13+ 通知权限引导。
 *
 * 能力：
 *   1. 原生桥自动检测（Capacitor 插件 / Android JS 接口）
 *   2. 通知权限（POST_NOTIFICATIONS）：说明弹窗 → 系统授权弹窗
 *   3. 媒体监听启停（前台服务 startListener / stopListener）
 *   4. 信息获取：事件推送 + 定时轮询 getCurrent()
 *   5. 状态持久化：wusiStorage 优先，localStorage 兜底
 *
 * 原生接口契约详见项目根目录 ANDROID_SETUP.md
 * 依赖：locales.js（通过 setLocale 注入语言包）、app.js 的 showToast（弱依赖）
 * ============================================================ */

var MediaBridge = (function(){

    // ========== 常量 ==========
    const STORE_KEY = "audioSpectrum.mediaBridge.v1";
    const POLL_MS_FOREGROUND = 1500;   // 前台轮询间隔
    const POLL_MS_HIDDEN = 5000;       // 页面不可见时降频
    const FIRST_PROMPT_DELAY = 1600;   // 首次启动引导弹窗延迟
    const STORAGE_RETRY_MS = 300;      // wusiStorage 就绪检测重试间隔
    const STORAGE_MAX_TRIES = 20;      // 最多重试次数（约 6 秒）

    // ========== 模块状态 ==========
    let locale = null;             // 语言包（由 app.js 注入）
    let bridge = null;             // 原生桥对象
    let bridgeMode = "none";       // "capacitor" | "android" | "none"
    let storageReady = false;      // wusiStorage 是否可用
    let initialized = false;
    let userInteracted = false;    // 用户是否手动操作过（避免存储回填覆盖）
    let pollTimer = null;
    let pendingPermResolver = null; // Android 异步权限结果中转
    let lastInfo = null;            // 最近一次媒体信息
    const state = {
        enabled: false,        // 是否开启媒体监听
        notifAsked: false,     // 是否已展示过权限说明弹窗
        permGranted: null,     // 通知权限 true / false / null(未知)
        listenerAccess: null   // 通知使用权 true / false / null(未知)
    };

    // ========== 基础工具 ==========
    function $(id){ return document.getElementById(id); }

    function getText(key, fallback){
        if(locale && typeof locale[key] === "string" && locale[key] !== "") return locale[key];
        return fallback || key;
    }

    function showToast(msg){
        if(!msg) return;
        if(typeof window.showToast === "function"){
            window.showToast(msg);
        }else{
            console.log("[MediaBridge] " + msg);
        }
    }

    function parseTruthy(v){
        if(v === true || v === "true" || v === 1 || v === "1") return true;
        if(v === false || v === "false" || v === 0 || v === "0") return false;
        return null;
    }

    // 解析原生返回的权限结果（兼容布尔 / 字符串 / 对象多种形态）
    function parsePermissionResult(res){
        if(res === true || res === "true" || res === "granted") return true;
        if(res === false || res === "false" || res === "denied") return false;
        if(res && typeof res === "object"){
            if(typeof res.granted === "boolean") return res.granted;
            if(typeof res.value === "boolean") return res.value;
            if(typeof res.notifications === "string") return res.notifications === "granted";
            if(typeof res.permission === "string") return res.permission === "granted";
            if(typeof res.value === "string") return res.value === "granted";
        }
        return null;
    }

    function firstString(){
        for(let i = 0; i < arguments.length; i++){
            const v = arguments[i];
            if(typeof v === "string" && v.trim() !== "") return v.trim();
        }
        return "";
    }

    // 归一化原生媒体信息（兼容对象 / JSON 字符串 / 多种字段名）
    function normalizeInfo(raw){
        if(raw === null || raw === undefined) return null;
        let obj = raw;
        if(typeof raw === "string"){
            const s = raw.trim();
            if(s === "" || s === "null") return null;
            try{ obj = JSON.parse(s); }catch(e){ return null; }
        }
        if(typeof obj !== "object" || obj === null) return null;
        const title = firstString(obj.title, obj.track, obj.song, obj.name);
        const artist = firstString(obj.artist, obj.artists, obj.subtitle, obj.text);
        const album = firstString(obj.album, obj.subText);
        const appName = firstString(obj.appName, obj.application, obj.packageName, obj.source);
        let isPlaying = null;
        if(typeof obj.isPlaying === "boolean") isPlaying = obj.isPlaying;
        else if(typeof obj.playing === "boolean") isPlaying = obj.playing;
        if(isPlaying === null){
            const ps = firstString(obj.isPlaying, obj.playing, obj.state);
            if(ps !== ""){
                const lower = ps.toLowerCase();
                if(lower === "true" || lower === "playing" || lower === "play") isPlaying = true;
                else if(lower === "false" || lower === "paused" || lower === "pause" || lower === "stopped") isPlaying = false;
            }
        }
        if(title === "" && artist === "") return null;
        return { title: title, artist: artist, album: album, appName: appName, isPlaying: isPlaying };
    }

    // ========== 存储（wusiStorage 优先，localStorage 兜底） ==========
    function isWusiStorageReady(){
        return !!(window.wusiStorage
            && typeof window.wusiStorage.getItem === "function"
            && typeof window.wusiStorage.setItem === "function"
            && typeof window.wusiStorage.getAll === "function");
    }

    function initStorage(onDone){
        let tries = 0;
        function check(){
            if(isWusiStorageReady()){
                storageReady = true;
                onDone();
                return;
            }
            tries++;
            if(tries >= STORAGE_MAX_TRIES){
                storageReady = false; // 降级为 localStorage
                onDone();
                return;
            }
            setTimeout(check, STORAGE_RETRY_MS);
        }
        check();
    }

    function normalizePersisted(v){
        if(!v || typeof v !== "object") return null;
        return {
            enabled: v.enabled === true,
            notifAsked: v.notifAsked === true,
            permGranted: (v.permGranted === true || v.permGranted === false) ? v.permGranted : null,
            listenerAccess: (v.listenerAccess === true || v.listenerAccess === false) ? v.listenerAccess : null
        };
    }

    function readPersisted(){
        try{
            if(storageReady && isWusiStorageReady()){
                return normalizePersisted(window.wusiStorage.getItem(STORE_KEY));
            }
            if(window.localStorage){
                const raw = window.localStorage.getItem(STORE_KEY);
                return raw ? normalizePersisted(JSON.parse(raw)) : null;
            }
        }catch(e){
            console.error("[MediaBridge] readPersisted error:", e);
        }
        return null;
    }

    function persistState(){
        const payload = {
            enabled: state.enabled,
            notifAsked: state.notifAsked,
            permGranted: state.permGranted,
            listenerAccess: state.listenerAccess
        };
        try{
            if(storageReady && isWusiStorageReady()){
                const ret = window.wusiStorage.setItem(STORE_KEY, payload);
                if(ret && typeof ret.catch === "function"){
                    ret.catch(function(e){ console.error("[MediaBridge] wusiStorage save error:", e); });
                }
            }else if(window.localStorage){
                window.localStorage.setItem(STORE_KEY, JSON.stringify(payload));
            }
        }catch(e){
            console.error("[MediaBridge] persistState error:", e);
        }
    }

    // ========== 原生桥检测与调用 ==========
    function detectBridge(){
        bridgeMode = "none";
        bridge = null;
        try{
            if(window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.MusicNotification){
                bridgeMode = "capacitor";
                bridge = window.Capacitor.Plugins.MusicNotification;
                return;
            }
        }catch(e){ console.error("[MediaBridge] detect capacitor error:", e); }
        try{
            if(window.MusicNotificationBridge && typeof window.MusicNotificationBridge === "object"){
                bridgeMode = "android";
                bridge = window.MusicNotificationBridge;
                return;
            }
        }catch(e){ console.error("[MediaBridge] detect android bridge error:", e); }
    }

    // 统一调用：兼容同步返回值与 Promise，任何异常都吞掉并返回 undefined
    function invokeBridge(fnName){
        return new Promise(function(resolve){
            if(bridgeMode === "none" || !bridge || typeof bridge[fnName] !== "function"){
                resolve(undefined);
                return;
            }
            try{
                const out = bridge[fnName]();
                if(out && typeof out.then === "function"){
                    out.then(function(res){ resolve(res); }).catch(function(err){
                        console.error("[MediaBridge] " + fnName + " rejected:", err);
                        resolve(undefined);
                    });
                }else{
                    resolve(out);
                }
            }catch(e){
                console.error("[MediaBridge] " + fnName + " threw:", e);
                resolve(undefined);
            }
        });
    }

    function bridgeGetCurrent(){
        return invokeBridge("getCurrent").then(function(res){
            return normalizeInfo(res);
        });
    }

    function bridgeStartListener(){ invokeBridge("startListener"); }
    function bridgeStopListener(){ invokeBridge("stopListener"); }

    function bridgeOpenSettings(){
        if(bridgeMode === "none" || !bridge || typeof bridge.openSettings !== "function") return false;
        invokeBridge("openSettings");
        return true;
    }

    // ========== 通知权限 ==========
    function webRequestPermission(){
        return new Promise(function(resolve){
            try{
                if(typeof Notification === "undefined" || typeof Notification.requestPermission !== "function"){
                    resolve(null);
                    return;
                }
                const r = Notification.requestPermission();
                if(r && typeof r.then === "function"){
                    r.then(function(res){ resolve(res === "granted"); }).catch(function(e){
                        console.error("[MediaBridge] Web Notification request error:", e);
                        resolve(null);
                    });
                }else{
                    resolve(null); // 旧式回调 API，不等结果
                }
            }catch(e){
                console.error("[MediaBridge] Web Notification unavailable:", e);
                resolve(null);
            }
        });
    }

    // 申请通知权限（原生优先，Web 兜底）；resolve: true/false/null(无法确认)
    function requestNotificationPermission(){
        return new Promise(function(resolve){
            // 1) Capacitor 插件
            if(bridgeMode === "capacitor" && bridge && typeof bridge.requestPermission === "function"){
                invokeBridge("requestPermission").then(function(res){
                    const parsed = parsePermissionResult(res);
                    if(parsed !== null){ resolve(parsed); return; }
                    webRequestPermission().then(resolve);
                });
                return;
            }
            // 2) Android JS 接口（结果经 window.onMediaNotificationPermissionResult 异步回调）
            if(bridgeMode === "android" && bridge && typeof bridge.requestNotificationPermission === "function"){
                let timer = null;
                pendingPermResolver = function(granted){
                    if(timer) clearTimeout(timer);
                    pendingPermResolver = null;
                    resolve(granted);
                };
                timer = setTimeout(function(){
                    if(!pendingPermResolver) return;
                    pendingPermResolver = null;
                    // 超时没等到回调：查一次现状，再不行走 Web 兜底
                    invokeBridge("hasNotificationPermission").then(function(hp){
                        const b = parseTruthy(hp);
                        if(b !== null) resolve(b);
                        else webRequestPermission().then(resolve);
                    });
                }, 6000);
                try{
                    bridge.requestNotificationPermission();
                }catch(e){
                    console.error("[MediaBridge] android requestNotificationPermission error:", e);
                    if(timer) clearTimeout(timer);
                    pendingPermResolver = null;
                    webRequestPermission().then(resolve);
                }
                return;
            }
            // 3) Web 兜底
            webRequestPermission().then(resolve);
        });
    }

    // 供原生层回调：系统权限弹窗关闭后调用 window.onMediaNotificationPermissionResult(granted)
    window.onMediaNotificationPermissionResult = function(granted){
        if(pendingPermResolver){
            const fn = pendingPermResolver;
            pendingPermResolver = null;
            fn(!!granted);
        }
    };

    // 查询原生侧权限/监听现状，刷新本地状态并重绘界面
    function refreshPermissionState(){
        if(bridgeMode === "none"){ updateUI(); return Promise.resolve(); }
        return invokeBridge("getPermissionStatus").then(function(status){
            if(status && typeof status === "object"){
                const perm = parsePermissionResult(status);
                if(perm !== null) state.permGranted = perm;
                if(typeof status.listenerEnabled === "boolean") state.listenerAccess = status.listenerEnabled;
                else if(typeof status.listener === "boolean") state.listenerAccess = status.listener;
            }
            return invokeBridge("hasNotificationPermission");
        }).then(function(hp){
            if(state.permGranted === null && hp !== undefined){
                const b = parseTruthy(hp);
                if(b !== null) state.permGranted = b;
            }
            return invokeBridge("isListenerEnabled");
        }).then(function(le){
            if(state.listenerAccess === null && le !== undefined){
                const b2 = parseTruthy(le);
                if(b2 !== null) state.listenerAccess = b2;
            }
            // Web 兜底：浏览器环境读取通知权限现状
            if(state.permGranted === null && typeof Notification !== "undefined" && Notification.permission){
                if(Notification.permission === "granted") state.permGranted = true;
                else if(Notification.permission === "denied") state.permGranted = false;
            }
            persistState();
            updateUI();
        }).catch(function(e){
            console.error("[MediaBridge] refreshPermissionState error:", e);
        });
    }

    // ========== 轮询与信息获取 ==========
    function schedulePoll(){
        stopPoll();
        if(!state.enabled || bridgeMode === "none") return;
        const interval = document.hidden ? POLL_MS_HIDDEN : POLL_MS_FOREGROUND;
        pollTimer = setTimeout(function(){
            pollTimer = null;
            refreshNow(true).then(function(){
                schedulePoll();
            });
        }, interval);
    }

    function stopPoll(){
        if(pollTimer){
            clearTimeout(pollTimer);
            pollTimer = null;
        }
    }

    function refreshNow(silent){
        if(bridgeMode === "none") return Promise.resolve(null);
        return bridgeGetCurrent().then(function(info){
            if(info){
                applyInfo(info);
            }
            return info;
        }).catch(function(e){
            console.error("[MediaBridge] refreshNow error:", e);
            return null;
        });
    }

    function applyInfo(info){
        if(!info) return;
        const changed = !lastInfo
            || lastInfo.title !== info.title
            || lastInfo.artist !== info.artist
            || lastInfo.appName !== info.appName
            || lastInfo.isPlaying !== info.isPlaying;
        lastInfo = info;
        if(changed) updateUI();
    }

    function handleIncoming(raw){
        const info = normalizeInfo(raw);
        if(info) applyInfo(info);
    }

    // ========== 界面渲染 ==========
    function renderSongBar(){
        const titleEl = $("songTitle");
        const artistEl = $("songArtist");
        const iconEl = $("songIcon");
        if(lastInfo && lastInfo.title){
            if(titleEl) titleEl.textContent = lastInfo.title;
            const parts = [];
            if(lastInfo.artist) parts.push(lastInfo.artist);
            if(lastInfo.appName) parts.push(lastInfo.appName);
            if(artistEl) artistEl.textContent = parts.length ? parts.join(" · ") : "—";
            if(iconEl){
                iconEl.classList.toggle("playing", lastInfo.isPlaying === true);
                iconEl.classList.toggle("paused", lastInfo.isPlaying === false);
            }
        }else{
            if(state.enabled && bridgeMode !== "none"){
                if(titleEl) titleEl.textContent = getText("songNone", "暂无播放");
                if(artistEl) artistEl.textContent = getText("songHint", "去放首歌试试");
            }else{
                if(titleEl) titleEl.textContent = "—";
                if(artistEl) artistEl.textContent = "—";
            }
            if(iconEl){
                iconEl.classList.remove("playing");
                iconEl.classList.remove("paused");
            }
        }
    }

    function updateUI(){
        // 开关与标签
        const chk = $("chkMediaListen");
        if(chk && chk.checked !== state.enabled) chk.checked = state.enabled;
        const lab = $("labMediaListen");
        if(lab) lab.innerText = getText("labMediaListen", "系统媒体监听");
        // 状态文案
        const st = $("mediaStatusText");
        if(st){
            let text = "";
            let cls = "";
            if(bridgeMode === "none"){
                text = getText("mediaStatusNoBridge", "当前环境不支持（打包 APK 后可用）");
                cls = "warn";
            }else if(!state.enabled){
                text = getText("mediaStatusOff", "已关闭");
            }else if(state.listenerAccess === false){
                text = getText("mediaStatusNoAccess", "还需在系统设置里开启「通知使用权」");
                cls = "warn";
            }else if(state.permGranted === false){
                text = getText("mediaStatusNoPerm", "建议允许通知权限");
                cls = "warn";
            }else if(lastInfo && lastInfo.title){
                text = getText("mediaStatusLive", "正在同步系统媒体播放信息");
                cls = "ok";
            }else{
                text = getText("mediaStatusWait", "监听中，等待音乐播放…");
                cls = "ok";
            }
            st.innerText = text;
            st.className = "media-status" + (cls ? " " + cls : "");
        }
        // 情境按钮：缺权限时「允许通知」，缺通知使用权时「去开启」
        const btn = $("btnMediaPerm");
        if(btn){
            let showBtn = false;
            let btnText = "";
            if(bridgeMode !== "none" && state.enabled){
                if(state.listenerAccess === false){
                    showBtn = true;
                    btnText = getText("btnMediaOpenSettings", "去开启");
                }else if(state.permGranted !== true){
                    showBtn = true;
                    btnText = getText("btnMediaPerm", "允许通知");
                }
            }
            btn.style.display = showBtn ? "block" : "none";
            if(showBtn) btn.innerText = btnText;
        }
        renderSongBar();
    }

    // ========== 权限说明弹窗 ==========
    function showPermModal(){
        const overlay = $("mediaPermOverlay");
        if(!overlay) return;
        const titleEl = $("mediaPermTitle");
        if(titleEl) titleEl.innerText = getText("permTitle", "开启系统媒体信息");
        const bodyEl = $("mediaPermBody");
        if(bodyEl) bodyEl.innerHTML = getText("permBody", "");
        const allow = $("btnMediaPermAllow");
        if(allow) allow.innerText = getText("permAllow", "允许");
        const later = $("btnMediaPermLater");
        if(later) later.innerText = getText("permLater", "暂不");
        overlay.style.display = "flex";
        // 弹过就记录，避免反复打扰
        if(!state.notifAsked){
            state.notifAsked = true;
            persistState();
        }
    }

    function closePermModal(){
        const overlay = $("mediaPermOverlay");
        if(overlay) overlay.style.display = "none";
    }

    function onModalAllow(){
        userInteracted = true;
        closePermModal();
        requestNotificationPermission().then(function(granted){
            if(granted === false){
                state.permGranted = false;
                persistState();
                updateUI();
                showToast(getText("toastPermDenied", "没拿到通知权限，可以稍后再试"));
                refreshPermissionState();
                return;
            }
            if(granted === true){
                state.permGranted = true;
                persistState();
                showToast(getText("toastPermGranted", "通知权限已开启"));
            }
            updateUI();
            setEnabled(true, { silent: true, noPrompt: true });
            if(granted === null) showToast(getText("toastMediaOn", "系统媒体监听已开启"));
            refreshPermissionState();
        });
    }

    function onModalLater(){
        userInteracted = true;
        closePermModal();
    }

    // ========== 监听开关 ==========
    function setEnabled(on, opts){
        opts = opts || {};
        userInteracted = true;
        if(on && bridgeMode === "none"){
            state.enabled = false;
            persistState();
            updateUI();
            if(!opts.silent) showToast(getText("toastMediaUnsupported", "当前环境不支持系统媒体监听"));
            return;
        }
        const wasEnabled = state.enabled;
        state.enabled = !!on;
        persistState();
        if(state.enabled){
            bridgeStartListener();
            schedulePoll();
            refreshNow(true);
            if(!opts.silent && !wasEnabled) showToast(getText("toastMediaOn", "系统媒体监听已开启"));
            if(state.permGranted !== true && !state.notifAsked && !opts.noPrompt){
                showPermModal();
            }
        }else{
            stopPoll();
            bridgeStopListener();
            if(!opts.silent && wasEnabled) showToast(getText("toastMediaOff", "系统媒体监听已关闭"));
        }
        updateUI();
    }

    // 设置面板情境按钮：优先补通知权限，其次引导通知使用权
    function onActionBtnClick(){
        userInteracted = true;
        if(state.listenerAccess === false){
            if(!bridgeOpenSettings()){
                showToast(getText("toastSettingsFail", "没成功打开系统设置"));
            }
            return;
        }
        requestNotificationPermission().then(function(granted){
            if(granted === true){
                state.permGranted = true;
                persistState();
                showToast(getText("toastPermGranted", "通知权限已开启"));
            }else if(granted === false){
                state.permGranted = false;
                persistState();
                showToast(getText("toastPermDenied", "没拿到通知权限，可以稍后再试"));
            }else{
                showToast(getText("toastMediaUnsupported", "当前环境无法确认通知权限"));
            }
            updateUI();
            refreshPermissionState();
        });
    }

    // ========== 事件绑定 ==========
    function bindUI(){
        const chk = $("chkMediaListen");
        if(chk){
            chk.checked = state.enabled;
            chk.addEventListener("change", function(){
                setEnabled(chk.checked);
            });
        }
        const btn = $("btnMediaPerm");
        if(btn) btn.addEventListener("click", onActionBtnClick);
        const allow = $("btnMediaPermAllow");
        if(allow) allow.addEventListener("click", onModalAllow);
        const later = $("btnMediaPermLater");
        if(later) later.addEventListener("click", onModalLater);
        const overlay = $("mediaPermOverlay");
        if(overlay){
            overlay.addEventListener("click", function(e){
                if(e.target === overlay) closePermModal();
            });
        }
    }

    function bindEvents(){
        // 原生推送（Capacitor 自定义事件 / 通用事件）
        window.addEventListener("musicInfo", function(e){
            if(e && e.detail) handleIncoming(e.detail);
        });
        window.addEventListener("musicState", function(e){
            if(e && e.detail) handleIncoming(e.detail);
        });

        // Android addJavascriptInterface 推送入口
        window.onMusicInfoUpdate = function(payload){
            try{ handleIncoming(payload); }catch(e){ console.error("[MediaBridge] onMusicInfoUpdate error:", e); }
        };

        // 兼容旧版原生调用：updateMusicInfo(title, artist) 或 updateMusicInfo({...})
        window.updateMusicInfo = function(title, artist, album, appName, isPlaying){
            let info;
            if(title && typeof title === "object"){
                info = title;
            }else{
                info = {
                    title: title,
                    artist: artist,
                    album: album,
                    appName: appName,
                    isPlaying: (typeof isPlaying === "boolean" ? isPlaying : null)
                };
            }
            try{ handleIncoming(info); }catch(e){ console.error("[MediaBridge] updateMusicInfo error:", e); }
        };

        // 页面可见性变化：回前台立即刷新一次，并调整轮询频率
        document.addEventListener("visibilitychange", function(){
            if(!document.hidden && state.enabled){
                refreshNow(true);
            }
            schedulePoll();
        });
    }

    // ========== 初始化 ==========
    function loadPersistedState(){
        if(userInteracted) return; // 用户已手动操作过，不回填
        const persisted = readPersisted();
        if(!persisted) return;
        state.enabled = persisted.enabled;
        state.notifAsked = persisted.notifAsked;
        state.permGranted = persisted.permGranted;
        state.listenerAccess = persisted.listenerAccess;
    }

    function afterStorageReady(){
        // 无桥接环境（如普通浏览器预览）：不保留开启状态，避免误解
        if(bridgeMode === "none" && state.enabled){
            state.enabled = false;
            persistState();
        }
        updateUI();
        if(bridgeMode === "none") return;
        refreshPermissionState();
        refreshNow(true); // 启动先取一次（兼容旧版行为）
        if(state.enabled){
            bridgeStartListener();
            schedulePoll();
        }else if(!state.notifAsked){
            // 首次启动：延迟弹一次说明弹窗，引导开启
            setTimeout(function(){
                if(!state.enabled && !state.notifAsked) showPermModal();
            }, FIRST_PROMPT_DELAY);
        }
    }

    function init(){
        if(initialized) return;
        initialized = true;
        detectBridge();
        bindUI();
        bindEvents();
        updateUI();
        initStorage(function(){
            loadPersistedState();
            afterStorageReady();
        });
    }

    // 语言包注入（由 app.js 在初次渲染与切换语言时调用）
    function setLocale(L){
        locale = L || null;
        updateUI();
    }

    // ========== 对外接口 ==========
    return {
        init: init,
        setLocale: setLocale,
        refreshNow: refreshNow,
        getState: function(){
            return {
                bridgeMode: bridgeMode,
                enabled: state.enabled,
                permGranted: state.permGranted,
                listenerAccess: state.listenerAccess,
                lastInfo: lastInfo
            };
        }
    };
})();

window.MediaBridge = MediaBridge;
