"use strict";

/* ============================================================
   app.js — Audio Spectrum 主逻辑（多文件版入口脚本）
   ------------------------------------------------------------
   模块划分：
     1. Toast 轻提示（替代 alert，供全应用与 MediaBridge 共用）
     2. 字体系统（字体检测 / 推荐弹窗 / 手动加载字体文件）
     3. 12 种界面主题
     4. 多语言（locales.js 字典；切换时同步 MediaBridge 文案）
     5. 18 种频谱配色 + 10 种按钮配色
     6. 背景漂浮粒子
     7. 画布与高 DPI（Retina）适配
     8. 麦克风采集与 14 种频谱绘制（渲染循环复用数据缓冲）
     9. 音量锁定按钮（APK / Capacitor 原生桥）
    10. 初始化（DOM 就绪后执行 + 超时兜底，挂接 MediaBridge）

   依赖加载顺序：locales.js → media-bridge.js → app.js
   ============================================================ */

// ========== 1. Toast 轻提示 ==========
const TOAST_MAX = 3;   // 同时最多显示 3 条
function showToast(msg, duration){
    try{
        const wrap = document.getElementById("toastWrap");
        if(!wrap){
            console.log("[Toast] " + msg);
            return;
        }
        while(wrap.children.length >= TOAST_MAX){
            wrap.removeChild(wrap.firstChild);
        }
        const el = document.createElement("div");
        el.className = "toast";
        el.textContent = String(msg == null ? "" : msg);
        wrap.appendChild(el);
        requestAnimationFrame(function(){
            el.classList.add("show");
        });
        const keep = typeof duration === "number" ? duration : 2600;
        setTimeout(function(){
            el.classList.remove("show");
            setTimeout(function(){
                if(el.parentNode) el.parentNode.removeChild(el);
            }, 320);
        }, keep);
    }catch(e){
        console.error("[Toast] error:", e);
    }
}
window.showToast = showToast;

// ========== 画布基础 ==========
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

// ========== 2. 字体系统 ==========
// 通过测宽法检测某字体是否真实可用
function checkFontAvailable(fontFamily){
    try{
        const testStr = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 あいう漢字";
        const c = document.createElement("canvas");
        const cctx = c.getContext("2d");
        const baseFont = "monospace";
        cctx.font = `20px ${baseFont}`;
        const baseWidth = cctx.measureText(testStr).width;
        cctx.font = `20px "${fontFamily}", ${baseFont}`;
        const testWidth = cctx.measureText(testStr).width;
        return Math.abs(baseWidth - testWidth) > 0.5;
    }catch(e){ return false; }
}

const fontDefine = [
    {key:"system", nameKey:"system", stack:"system-ui,-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif"},
    {key:"YouMengTi", nameKey:"youmeng", stack:'"YouMengTi",system-ui,sans-serif'},
    {key:"LXGW WenKai", nameKey:"lxgw", stack:'"LXGW WenKai",system-ui,sans-serif'},
    {key:"Source Han Serif CN", nameKey:"sourceHanSerif", stack:'"Source Han Serif CN","Noto Serif SC",serif'},
    {key:"JingNanYuanMo", nameKey:"yuanmo", stack:'"JingNanYuanMo",system-ui,sans-serif'},
    {key:"TieJiLiTi", nameKey:"tiejili", stack:'"TieJiLiTi",system-ui,sans-serif'},
    {key:"LXGW ZhenKai", nameKey:"zhenkai", stack:'"LXGW ZhenKai",system-ui,sans-serif'},
    {key:"JiangChengJieXing", nameKey:"jiexing", stack:'"JiangChengJieXing",system-ui,sans-serif'},
    {key:"ZhongHuaXinHuo", nameKey:"xinhuo", stack:'"ZhongHuaXinHuo",system-ui,sans-serif'},
    {key:"HuiJiZhengKai", nameKey:"huiji", stack:'"HuiJiZhengKai",system-ui,sans-serif'},
    {key:"HanChanZhuoKai", nameKey:"hanchan", stack:'"HanChanZhuoKai",system-ui,sans-serif'},
    {key:"ShanWeiZhouHei16", nameKey:"shanwei", stack:'"ShanWeiZhouHei16",system-ui,sans-serif'}
];
let availableFonts = [];
let customFonts = [];
function initAvailableFonts(){
    availableFonts = fontDefine.filter(f=>{
        if(f.key==="system") return true;
        return checkFontAvailable(f.key);
    }).concat(customFonts);
}

// 手动加载字体文件（多选；成功后自动切换到最后新增的字体）
async function handleModalFontFile(){
    const mf = document.getElementById("modalFontFile");
    if(!mf || !mf.files || mf.files.length===0) return;
    const files = Array.from(mf.files);
    const fb = document.getElementById("fontFeedback");
    let added = 0, failed = 0;
    for(const file of files){
        try{
            const raw = (file.name.replace(/\.(ttf|otf|woff|woff2)$/i,"") || "custom").trim();
            const url = URL.createObjectURL(file);
            const ff = new FontFace(raw, `url(${url})`);
            await ff.load();
            document.fonts.add(ff);
            if(!customFonts.some(c=>c.key===raw)){
                customFonts.push({key:raw, nameKey:raw, stack:`"${raw}",system-ui,sans-serif`});
            }
            added++;
        }catch(e){ failed++; console.error("[App] font load error:", e); }
    }
    if(added>0){
        initAvailableFonts();
        rebuildSelectOptions();
        currentFontIndex = availableFonts.length-1;
        selFont.value = currentFontIndex;
        applySelectedFont();
    }
    if(fb){
        fb.textContent = added>0
            ? (failed>0 ? L.fontAddOk.replace("{n}",added)+" "+L.fontAddFail.replace("{n}",failed) : L.fontAddOk.replace("{n}",added))
            : L.fontAddFail.replace("{n}",files.length);
        fb.style.color = failed>0 ? "#e0a07e" : "#7ee0a0";
    }
    mf.value = "";
}

// ========== 3. 界面风格主题（12种） ==========
const uiThemeList = [
    "theme-skeuomorphic","theme-flat","theme-glass","theme-neon",
    "theme-pill","theme-outline","theme-metal","theme-gradient",
    "theme-pixel","theme-3d","theme-ink","theme-cyber"
];
let currentUiStyleIndex = 0;
function applyUiTheme(){
    document.body.classList.remove(...uiThemeList);
    document.body.classList.add(uiThemeList[currentUiStyleIndex]);
}

// ========== 4. 多语言状态 ==========
/* locales 字典定义在 locales.js 中（全局 const locales） */
let currentLangIndex = 0;
const langKeys = ["zh-CN","zh-TW","en","ja"];
let L = locales[langKeys[currentLangIndex]];

// ========== 弹窗控制（设置面板） ==========
const overlay = document.getElementById("settingsOverlay");
const fontModalOverlay = document.getElementById("fontModalOverlay");
const fontModalTitleEl = document.getElementById("fontModalTitle");
const fontModalContentEl = document.getElementById("fontModalContent");
const fftRow = document.getElementById("fftRow");

function openSettings(){ overlay.style.display="flex"; }
function closeSettings(){ overlay.style.display="none"; }
overlay.addEventListener('click',function(e){if(e.target===overlay)closeSettings();});

function openFontModal(){
    fontModalTitleEl.innerText = L.fontModal.title;
    fontModalContentEl.innerHTML = L.fontModal.content;
    const mf = document.getElementById("modalFontFile");
    if(mf) mf.onchange = handleModalFontFile;
    fontModalOverlay.style.display="flex";
}
function closeFontModal(){ fontModalOverlay.style.display="none"; }
fontModalOverlay.addEventListener('click',function(e){if(e.target===fontModalOverlay)closeFontModal();});

// ========== 推荐字体弹窗 ==========
const fontRecOverlay = document.getElementById("fontRecOverlay");
const fontRecListEl = document.getElementById("fontRecList");

function openFontRecModal(){
    document.getElementById("fontRecTitle").innerText = L.fontRecTitle;
    document.getElementById("fontRecSub").innerText = L.fontRecSub;
    document.querySelector(".font-rec-footer button").innerText = L.btnClose;
    renderFontRecList();
    fontRecOverlay.style.display="flex";
}
function closeFontRecModal(){ fontRecOverlay.style.display="none"; }
fontRecOverlay.addEventListener('click',function(e){if(e.target===fontRecOverlay)closeFontRecModal();});

// 渲染推荐字体列表：已装的可直接切换，未装的点击整行去添加
function renderFontRecList(){
    fontRecListEl.innerHTML="";
    fontDefine.forEach(function(f){
        if(f.key==="system") return;
        const isAvail = checkFontAvailable(f.key);
        const isActive = availableFonts.some(function(af){return af.key===f.key;}) && currentFontIndex === availableFonts.findIndex(function(af){return af.key===f.key;});
        const item = document.createElement("div");
        item.className = "font-rec-item" + (isActive?" active":"") + (!isAvail?" missing-clickable":"");
        const nameDiv = document.createElement("div");
        const nameEl = document.createElement("div");
        nameEl.className = "font-rec-name";
        nameEl.textContent = L.fontNames[f.nameKey] || f.key;
        const statusEl = document.createElement("div");
        statusEl.className = "font-rec-status " + (isAvail?"avail":"missing");
        statusEl.textContent = isAvail ? L.fontRecAvail : L.fontRecMissing;
        nameDiv.appendChild(nameEl);
        nameDiv.appendChild(statusEl);
        item.appendChild(nameDiv);
        if(isAvail){
            const btn = document.createElement("button");
            btn.className = "rec-apply";
            btn.textContent = L.fontRecApply;
            btn.onclick = function(e){
                e.stopPropagation();
                const afIdx = availableFonts.findIndex(function(af){return af.key===f.key;});
                if(afIdx>=0){
                    currentFontIndex = afIdx;
                    selFont.value = afIdx;
                    applySelectedFont();
                    renderFontRecList();
                }
            };
            item.appendChild(btn);
        }else{
            item.onclick = function(){
                closeFontRecModal();
                openFontModal();
            };
        }
        fontRecListEl.appendChild(item);
    });
}

// ========== 设置面板控件引用 ==========
const selStyle = document.getElementById("selStyle");
const selColor = document.getElementById("selColor");
const selUiStyle = document.getElementById("selUiStyle");
const selBtnColor = document.getElementById("selBtnColor");
const selFftSize = document.getElementById("selFftSize");
const selFont = document.getElementById("selFont");
const selLang = document.getElementById("selLang");

// ========== 5. 按钮颜色（统一所有按钮） ==========
const btnColorPalette = ["#2970ff","#d62828","#22aa55","#9933dd","#ff7722","#333338","#ff4d8d","#00bcd4","#ffc107","#f5f5f5"];
let currentBtnColorIndex = 0;
function lightenColor(hex,p){
    const n=parseInt(hex.replace("#",""),16);
    const r=Math.min(255,(n>>16)+p),g=Math.min(255,((n>>8)&255)+p),b=Math.min(255,(n&255)+p);
    return `#${((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1)}`;
}
function darkenColor(hex,p){
    const n=parseInt(hex.replace("#",""),16);
    const r=Math.max(0,(n>>16)-p),g=Math.max(0,((n>>8)&255)-p),b=Math.max(0,(n&255)-p);
    return `#${((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1)}`;
}
function applyBtnColor(){
    const c = btnColorPalette[currentBtnColorIndex];
    document.documentElement.style.setProperty('--btn-main', c);
    document.documentElement.style.setProperty('--btn-light', lightenColor(c,15));
    document.documentElement.style.setProperty('--btn-dark', darkenColor(c,20));
    document.documentElement.style.setProperty('--btn-glow', c+'88');
}

// ========== 字体应用 ==========
let currentFontIndex = 0;
function applySelectedFont(){
    if(availableFonts[currentFontIndex]){
        document.body.style.fontFamily = availableFonts[currentFontIndex].stack;
    }
}

// ========== 6. 背景漂浮粒子 ==========
const chkBgParticle = document.getElementById("chkBgParticle");
const selBgDensity = document.getElementById("selBgDensity");
const bgParticleDensityRow = document.getElementById("bgParticleDensityRow");
let enableBgParticle = true;
let bgParticleDensityIndex = 1;
const bgParticleCounts = [60, 120, 200, 320];
let bgParticles = [];

function initBgParticles(){
    bgParticles = [];
    const count = bgParticleCounts[bgParticleDensityIndex];
    for(let i=0;i<count;i++){
        bgParticles.push({
            x:Math.random(),
            y:Math.random(),
            vx:(Math.random()-0.5)*0.0015,
            vy:(Math.random()-0.5)*0.001-0.0006,
            size:1+Math.random()*2,
            hue:Math.random()*360,
            phase:Math.random()*Math.PI*2,
            twinkle:0.3+Math.random()*0.7
        });
    }
}

function drawBgParticles(w,h){
    if(!enableBgParticle) return;
    if(bgParticles.length===0) initBgParticles();
    for(let i=0;i<bgParticles.length;i++){
        const p=bgParticles[i];
        p.phase += 0.015;
        p.x += p.vx + Math.sin(p.phase)*0.0008;
        p.y += p.vy;
        p.hue += 0.15;
        if(p.y < -0.05){p.y=1.05;p.x=Math.random();}
        if(p.y > 1.05)p.y=-0.05;
        if(p.x < -0.05)p.x=1.05;
        if(p.x > 1.05)p.x=-0.05;
        const px=p.x*w, py=p.y*h;
        const twinkleAlpha = 0.4 + Math.sin(p.phase*2)*0.3*p.twinkle;
        ctx.beginPath();
        ctx.arc(px,py,p.size*2.5,0,Math.PI*2);
        ctx.fillStyle=`hsla(${p.hue%360},80%,65%,${twinkleAlpha*0.25})`;
        ctx.fill();
        ctx.beginPath();
        ctx.arc(px,py,p.size,0,Math.PI*2);
        ctx.fillStyle=`hsla(${p.hue%360},85%,70%,${twinkleAlpha})`;
        ctx.fill();
    }
}

chkBgParticle.onchange = function(){
    enableBgParticle = chkBgParticle.checked;
    bgParticleDensityRow.style.display = enableBgParticle ? "block" : "none";
    if(enableBgParticle && bgParticles.length===0) initBgParticles();
};
selBgDensity.onchange = function(){
    bgParticleDensityIndex = Number(selBgDensity.value);
    initBgParticles();
};

let currentFftSize = 1024;

// ========== 重建下拉选项 ==========
function rebuildSelectOptions(){
    selStyle.innerHTML="";
    L.styleList.forEach(function(name,i){
        const o=document.createElement("option");o.value=i;o.textContent=name;selStyle.appendChild(o);
    });
    selStyle.value=currentStyleIndex;

    selColor.innerHTML="";
    L.colorList.forEach(function(name,i){
        const o=document.createElement("option");o.value=i;o.textContent=name;selColor.appendChild(o);
    });
    selColor.value=currentColorIndex;

    selUiStyle.innerHTML="";
    L.uiStyleList.forEach(function(name,i){
        const o=document.createElement("option");o.value=i;o.textContent=name;selUiStyle.appendChild(o);
    });
    selUiStyle.value=currentUiStyleIndex;

    selBtnColor.innerHTML="";
    L.btnColorList.forEach(function(name,i){
        const o=document.createElement("option");o.value=i;o.textContent=name;selBtnColor.appendChild(o);
    });
    selBtnColor.value=currentBtnColorIndex;

    selFftSize.innerHTML="";
    L.fftSizeList.forEach(function(v){
        const o=document.createElement("option");o.value=v;o.textContent=v;selFftSize.appendChild(o);
    });
    selFftSize.value=currentFftSize;

    selFont.innerHTML="";
    availableFonts.forEach(function(f,i){
        const o=document.createElement("option");
        o.value=i;
        o.textContent = L.fontNames[f.nameKey] || f.key;
        selFont.appendChild(o);
    });
    selFont.value=Math.min(currentFontIndex,availableFonts.length-1);

    selLang.innerHTML="";
    L.langNames.forEach(function(name,i){
        const o=document.createElement("option");o.value=i;o.textContent=name;selLang.appendChild(o);
    });
    selLang.value=currentLangIndex;

    selBgDensity.innerHTML="";
    L.bgDensityList.forEach(function(name,i){
        const o=document.createElement("option");o.value=i;o.textContent=name;selBgDensity.appendChild(o);
    });
    selBgDensity.value=bgParticleDensityIndex;
}

// 刷新全部界面文案；切换语言后同步 MediaBridge 语言包
function updateLocaleUI(){
    L = locales[langKeys[currentLangIndex]];
    document.getElementById("mainTip").innerText = L.tip;
    const btn = document.getElementById('startBtn');
    if(isRunning){
        btn.innerText = L.btnRunning;
    }else{
        btn.innerText = L.btnStart;
    }
    document.querySelector('.main-ctrl button.secondary').innerText = L.btnSettings;
    document.querySelector('.panel-footer button').innerText = L.btnClose;
    var setRowBtns = document.querySelectorAll('.settings-panel .set-row > button');
    if(setRowBtns[0]) setRowBtns[0].innerText = L.btnFontRec;

    document.getElementById("labStyle").innerText=L.labStyle;
    document.getElementById("labColor").innerText=L.labColor;
    document.getElementById("labUiStyle").innerText=L.labUiStyle;
    document.getElementById("labBtnColor").innerText=L.labBtnColor;
    document.getElementById("labFftSize").innerText=L.labFftSize;
    document.getElementById("labFont").innerText=L.labFont;
    document.getElementById("labBgParticle").innerText=L.labBgParticle;
    document.getElementById("labBgDensity").innerText=L.labBgDensity;
    document.getElementById("labLang").innerText=L.labLang;
    document.getElementById("labSen").innerText=L.labSen;
    document.getElementById("labSmooth").innerText=L.labSmooth;
    rebuildSelectOptions();
    applySelectedFont();
    if(typeof updateVolBtnText === "function") updateVolBtnText();
    // 系统媒体监听模块的界面文案同步
    if(window.MediaBridge && typeof window.MediaBridge.setLocale === "function"){
        window.MediaBridge.setLocale(L);
    }
}

selStyle.onchange=function(){
    currentStyleIndex=Number(selStyle.value);
};
selColor.onchange=function(){currentColorIndex=Number(selColor.value);};
selUiStyle.onchange=function(){currentUiStyleIndex=Number(selUiStyle.value);applyUiTheme();};
selBtnColor.onchange=function(){currentBtnColorIndex=Number(selBtnColor.value);applyBtnColor();};
selFftSize.onchange=function(){
    currentFftSize=Number(selFftSize.value);
    if(analyser) analyser.fftSize=currentFftSize;
};
selFont.onchange=function(){currentFontIndex=Number(selFont.value);applySelectedFont();};
selLang.onchange=function(){currentLangIndex=Number(selLang.value);updateLocaleUI();};

// ========== 5. 配色（18种） ==========
const colorModes=[
    function(v){return `hsl(${v},90%,60%)`;},
    function(v){const b=40+(v/255)*60;return`hsl(210,100%,${b}%)`;},
    function(v){const b=40+(v/255)*55;return`hsl(320,95%,${b}%)`;},
    function(v){const b=30+(v/255)*50;return`hsl(150,85%,${b}%)`;},
    function(v){const a=0.25+(v/255)*0.75;return`rgba(255,255,255,${a})`;},
    function(v){const b=35+(v/255)*60;return`hsl(275,100%,${b}%)`;},
    function(v){const b=40+(v/255)*60;return`hsl(185,100%,${b}%)`;},
    function(v){const b=40+(v/255)*60;return`hsl(35,100%,${b}%)`;},
    function(v){const b=45+(v/255)*45;return`hsl(220,20%,${b}%)`;},
    function(v){const b=45+(v/255)*55;return`hsl(165,75%,${b}%)`;},
    function(v){const b=35+(v/255)*55;return`hsl(0,95%,${b}%)`;},
    function(v){const b=30+(v/255)*60;return`hsl(235,90%,${b}%)`;},
    function(v){const b=45+(v/255)*50;return`hsl(340,85%,${b}%)`;},
    function(v){const b=40+(v/255)*55;return`hsl(45,100%,${b}%)`;},
    function(v){const b=40+(v/255)*55;return`hsl(90,80%,${b}%)`;},
    function(v){const b=40+(v/255)*55;return`hsl(15,90%,${b}%)`;},
    function(v){const b=40+(v/255)*55;return`hsl(265,70%,${b}%)`;},
    function(v){const b=35+(v/255)*55;return`hsl(160,75%,${b}%)`;}
];
let currentColorIndex=0;
function getColor(vol){return colorModes[currentColorIndex](vol);}

// 为颜色追加透明度：兼容 hsl(...) 与 rgba(...) 两种返回形态
function colorWithAlpha(color, alpha){
    try{
        if(color.indexOf("hsl(") === 0){
            return color.replace("hsl(", "hsla(").replace(")", "," + alpha + ")");
        }
        if(color.indexOf("rgba(") === 0){
            return color.replace(/,[^,]*\)$/, "," + alpha + ")");
        }
    }catch(e){ console.error("[App] colorWithAlpha error:", e); }
    return color;
}

let audioCtx, analyser, mediaStream;
let isRunning = false;
let currentStyleIndex=0;

// ========== 频谱风格（14种） ==========
const styleList=[
    {fn:drawPixelGrid},
    {fn:drawDualBarSpectrum},
    {fn:drawRingSpectrum},
    {fn:drawLineDotWave},
    {fn:drawBottomBar},
    {fn:drawMirrorWave},
    {fn:drawSpiral},
    {fn:drawRainLine},
    {fn:drawCircleDot},
    {fn:drawHorizontalStack},
    {fn:drawDenseHorizontal},
    {fn:drawAnalogNeedle},
    {fn:drawDualNeedleGauge},
    {fn:drawRadialLines}
];
let sensitivity=1.0;

// ========== 画布尺寸 & 高 DPI（Retina）适配 ==========
function resizeCanvas(){
    const dpr = window.devicePixelRatio || 1;
    canvas.width = Math.max(1, Math.round(canvas.clientWidth * dpr));
    canvas.height = Math.max(1, Math.round(canvas.clientHeight * dpr));
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}
window.addEventListener('resize', resizeCanvas);
window.addEventListener('load', function(){ resizeCanvas(); });
window.addEventListener('orientationchange', function(){
    setTimeout(resizeCanvas, 260);
});

// ========== 灵敏度 / 平滑度 ==========
const senSlider=document.getElementById("sensitivitySlider");
const smoothSlider=document.getElementById("smoothSlider");
senSlider.oninput=function(){
    sensitivity=parseFloat(senSlider.value);
    document.getElementById("senVal").textContent=sensitivity.toFixed(1);
};
smoothSlider.oninput=function(){
    const v=parseFloat(smoothSlider.value);
    document.getElementById("smoothVal").textContent=v.toFixed(2);
    if(analyser) analyser.smoothingTimeConstant=v;
};

// ========== 麦克风采集 ==========
async function toggleMicCapture(){
    if(isRunning){
        stopMicCapture();
        return;
    }
    try{
        mediaStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false},video:false});
        audioCtx=new (window.AudioContext||window.webkitAudioContext)();
        analyser=audioCtx.createAnalyser();
        analyser.fftSize=currentFftSize;
        analyser.smoothingTimeConstant=parseFloat(smoothSlider.value);
        const source=audioCtx.createMediaStreamSource(mediaStream);
        source.connect(analyser);
        isRunning=true;
        renderLoop();
        document.getElementById('startBtn').innerText=L.btnRunning;
        fftRow.style.display="block";
    }catch(err){
        console.error("[App] mic capture error:", err);
        showToast(L.micFail.replace("{err}", (err && err.message) ? err.message : String(err)), 3600);
    }
}

function stopMicCapture(){
    isRunning=false;
    if(mediaStream){
        mediaStream.getTracks().forEach(function(t){t.stop();});
        mediaStream=null;
    }
    if(audioCtx){
        audioCtx.close().catch(function(e){ console.error("[App] audioCtx close error:", e); });
        audioCtx=null;
    }
    analyser=null;
    document.getElementById('startBtn').innerText=L.btnStart;
    fftRow.style.display="none";
}

// ========== 渲染循环（复用频谱数据缓冲，降低 GC 压力） ==========
let freqData = null;        // 复用的频谱数据数组
let freqDataLength = 0;     // 当前缓冲长度（随 FFT 档位变化）

function ensureFreqData(length){
    if(!freqData || freqDataLength !== length){
        freqData = new Uint8Array(length);
        freqDataLength = length;
    }
}

function renderLoop(){
    if(!isRunning) return;
    requestAnimationFrame(renderLoop);
    if(!analyser) return;
    const w=canvas.clientWidth,h=canvas.clientHeight;
    const bufferLength=analyser.frequencyBinCount;
    ensureFreqData(bufferLength);
    analyser.getByteFrequencyData(freqData);
    ctx.clearRect(0,0,w,h);
    const style = styleList[currentStyleIndex] || styleList[0];
    style.fn(w,h,bufferLength,freqData);
    drawBgParticles(w,h);
}

// ========== 频谱绘制函数（14种） ==========
function drawPixelGrid(w,h,bufferLength,dataArray){
    const gridCount=28,blockSize=8,colWidth=w/gridCount;
    for(let col=0;col<gridCount;col++){
        const idx=Math.floor(col/gridCount*bufferLength);
        let vol=dataArray[idx]*sensitivity;
        if(vol>255)vol=255;
        const maxBlocks=Math.floor(h/blockSize);
        const lightBlocks=Math.floor(vol/255*maxBlocks);
        for(let b=0;b<lightBlocks;b++){
            const y=h-(b+1)*blockSize;
            ctx.fillStyle=getColor(vol);
            ctx.fillRect(col*colWidth+2,y,blockSize,blockSize-1);
        }
    }
}

function drawDualBarSpectrum(w,h,bufferLength,dataArray){
    const barCnt=56,gap=2,barW=(w/barCnt)-gap,midY=h/2;
    for(let i=0;i<barCnt;i++){
        const idx=Math.floor(i/barCnt*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const halfH=(v/255)*h*0.42;
        const x=i*(w/barCnt);
        ctx.fillStyle=getColor(v);
        ctx.fillRect(x,midY-halfH,barW,halfH);
        ctx.fillRect(x,midY,barW,halfH);
    }
}

function drawRingSpectrum(w,h,bufferLength,dataArray){
    const cx=w/2,cy=h/2,baseR=Math.min(w,h)*0.25,segments=120;
    ctx.beginPath();
    for(let i=0;i<segments;i++){
        const idx=Math.floor(i/segments*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const ang=(i/segments)*Math.PI*2;
        const r=baseR+(v/255)*Math.min(w,h)*0.32;
        const x=cx+Math.cos(ang)*r,y=cy+Math.sin(ang)*r;
        i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
    }
    ctx.closePath();
    ctx.strokeStyle=getColor(180);ctx.lineWidth=3;ctx.stroke();
    ctx.fillStyle=colorWithAlpha(getColor(180),0.15);
    ctx.fill();
}

function drawLineDotWave(w,h,bufferLength,dataArray){
    const dotCount=90;
    ctx.beginPath();
    for(let i=0;i<dotCount;i++){
        const idx=Math.floor(i/dotCount*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const x=(i/dotCount)*w,y=h/2-((v/255)*h*0.45);
        i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
    }
    ctx.strokeStyle=getColor(200);ctx.lineWidth=2;ctx.stroke();
    for(let i=0;i<dotCount;i++){
        const idx=Math.floor(i/dotCount*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const x=(i/dotCount)*w,y=h/2-((v/255)*h*0.45);
        ctx.beginPath();ctx.arc(x,y,2.5,0,Math.PI*2);
        ctx.fillStyle=getColor(v);ctx.fill();
    }
}

function drawBottomBar(w,h,bufferLength,dataArray){
    const barCnt=60,gap=1,barW=w/barCnt-gap;
    for(let i=0;i<barCnt;i++){
        const idx=Math.floor(i/barCnt*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const bh=(v/255)*h*0.9;
        ctx.fillStyle=getColor(v);
        ctx.fillRect(i*(w/barCnt),h-bh,barW,bh);
    }
}

function drawMirrorWave(w,h,bufferLength,dataArray){
    const count=80;
    ctx.beginPath();
    for(let i=0;i<count;i++){
        const idx=Math.floor(i/count*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const x=(i/count)*w,off=(v/255)*h*0.38,y1=h-off;
        i===0?ctx.moveTo(x,y1):ctx.lineTo(x,y1);
    }
    for(let i=count-1;i>=0;i--){
        const idx=Math.floor(i/count*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const x=(i/count)*w,off=(v/255)*h*0.38,y2=h+off;
        ctx.lineTo(x,y2);
    }
    ctx.closePath();
    ctx.fillStyle=colorWithAlpha(getColor(160),0.35);ctx.fill();
    ctx.strokeStyle=getColor(200);ctx.lineWidth=2;ctx.stroke();
}

function drawSpiral(w,h,bufferLength,dataArray){
    const cx=w/2,cy=h/2,turns=2.5,seg=180;
    ctx.beginPath();
    for(let i=0;i<seg;i++){
        const idx=Math.floor(i/seg*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const t=i/seg,ang=t*Math.PI*2*turns;
        const baseR=Math.min(w,h)*0.08+t*Math.min(w,h)*0.35;
        const r=baseR+(v/255)*25;
        const x=cx+Math.cos(ang)*r,y=cy+Math.sin(ang)*r;
        i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
    }
    ctx.strokeStyle=getColor(190);ctx.lineWidth=2.5;ctx.stroke();
}

function drawRainLine(w,h,bufferLength,dataArray){
    const lineCnt=72;
    for(let i=0;i<lineCnt;i++){
        const idx=Math.floor(i/lineCnt*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const lh=(v/255)*h*0.88,x=(i/lineCnt)*w;
        ctx.beginPath();ctx.moveTo(x,h);ctx.lineTo(x,h-lh);
        ctx.strokeStyle=getColor(v);ctx.lineWidth=2;ctx.stroke();
    }
}

function drawCircleDot(w,h,bufferLength,dataArray){
    const cx=w/2,cy=h/2,dotCount=144;
    for(let i=0;i<dotCount;i++){
        const idx=Math.floor(i/dotCount*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const ang=(i/dotCount)*Math.PI*2;
        const r=Math.min(w,h)*0.18+(v/255)*Math.min(w,h)*0.30;
        const x=cx+Math.cos(ang)*r,y=cy+Math.sin(ang)*r;
        ctx.beginPath();ctx.arc(x,y,2+(v/100)*3,0,Math.PI*2);
        ctx.fillStyle=getColor(v);ctx.fill();
    }
}

// ===== 横线堆叠 =====
function drawHorizontalStack(w,h,bufferLength,dataArray){
    const lineCount=48;
    const lineH=h/lineCount;
    for(let i=0;i<lineCount;i++){
        const idx=Math.floor(i/lineCount*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const lineW=(v/255)*w*0.85;
        const y=i*lineH+lineH*0.2;
        const x=(w-lineW)/2;
        ctx.fillStyle=getColor(v);
        ctx.fillRect(x,y,lineW,lineH*0.6);
    }
}

// ===== 密集横线 =====
function drawDenseHorizontal(w,h,bufferLength,dataArray){
    const lineCount=120;
    const lineH=h/lineCount;
    for(let i=0;i<lineCount;i++){
        const idx=Math.floor(i/lineCount*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const lineW=(v/255)*w*0.9;
        const y=i*lineH;
        const x=(w-lineW)/2;
        ctx.fillStyle=colorWithAlpha(getColor(v),0.75);
        ctx.fillRect(x,y,lineW,Math.max(1,lineH*0.7));
    }
}

// ===== 模拟指针（VU表） =====
function drawAnalogNeedle(w,h,bufferLength,dataArray){
    const cx=w/2,cy=h*0.62;
    const radius=Math.min(w,h)*0.38;
    const startAngle=Math.PI*0.75;
    const endAngle=Math.PI*2.25;
    // 计算平均音量
    let sum=0;
    const sampleCount=Math.min(bufferLength,64);
    for(let i=0;i<sampleCount;i++){
        sum+=dataArray[Math.floor(i/sampleCount*bufferLength)];
    }
    let avg=sum/sampleCount*sensitivity;
    if(avg>255)avg=255;
    const volRatio=avg/255;
    // 画表盘弧
    ctx.beginPath();
    ctx.arc(cx,cy,radius,startAngle,endAngle);
    ctx.strokeStyle="#33333f";ctx.lineWidth=12;ctx.stroke();
    // 画彩色弧
    const needleAngle=startAngle+(endAngle-startAngle)*volRatio;
    ctx.beginPath();
    ctx.arc(cx,cy,radius,startAngle,needleAngle);
    ctx.strokeStyle=getColor(avg);ctx.lineWidth=12;ctx.stroke();
    // 画刻度
    const tickCount=11;
    for(let i=0;i<=tickCount;i++){
        const t=i/tickCount;
        const ang=startAngle+(endAngle-startAngle)*t;
        const innerR=radius-18,outerR=radius-8;
        ctx.beginPath();
        ctx.moveTo(cx+Math.cos(ang)*innerR,cy+Math.sin(ang)*innerR);
        ctx.lineTo(cx+Math.cos(ang)*outerR,cy+Math.sin(ang)*outerR);
        ctx.strokeStyle=t<=volRatio?getColor(avg):"#555";
        ctx.lineWidth=2;ctx.stroke();
    }
    // 画指针
    const needleLen=radius*0.85;
    ctx.beginPath();
    ctx.moveTo(cx,cy);
    ctx.lineTo(cx+Math.cos(needleAngle)*needleLen,cy+Math.sin(needleAngle)*needleLen);
    ctx.strokeStyle=getColor(200);ctx.lineWidth=3;ctx.lineCap="round";ctx.stroke();
    // 指针中心圆
    ctx.beginPath();ctx.arc(cx,cy,8,0,Math.PI*2);
    ctx.fillStyle=getColor(180);ctx.fill();
    ctx.beginPath();ctx.arc(cx,cy,4,0,Math.PI*2);
    ctx.fillStyle="#111";ctx.fill();
    // 数值
    ctx.fillStyle="#aaa";ctx.font="14px monospace";ctx.textAlign="center";
    ctx.fillText(Math.round(volRatio*100)+"%",cx,cy+radius*0.4);
}

// ===== 双针表盘 =====
function drawDualNeedleGauge(w,h,bufferLength,dataArray){
    const leftCx=w*0.3,rightCx=w*0.7,cy=h*0.55;
    const radius=Math.min(w*0.22,h*0.35);
    const startAngle=Math.PI*0.75;
    const endAngle=Math.PI*2.25;
    // 左表：低频
    let lowSum=0,lowCount=Math.floor(bufferLength*0.3);
    for(let i=0;i<lowCount;i++) lowSum+=dataArray[i];
    let lowAvg=lowSum/Math.max(1,lowCount)*sensitivity;
    if(lowAvg>255)lowAvg=255;
    // 右表：高频
    let highSum=0,highStart=Math.floor(bufferLength*0.5);
    let highCount=bufferLength-highStart;
    for(let i=highStart;i<bufferLength;i++) highSum+=dataArray[i];
    let highAvg=highSum/Math.max(1,highCount)*sensitivity;
    if(highAvg>255)highAvg=255;

    function drawGauge(cx,avg,label){
        const volRatio=avg/255;
        const needleAngle=startAngle+(endAngle-startAngle)*volRatio;
        // 底弧
        ctx.beginPath();ctx.arc(cx,cy,radius,startAngle,endAngle);
        ctx.strokeStyle="#2a2a35";ctx.lineWidth=10;ctx.stroke();
        // 彩色弧
        ctx.beginPath();ctx.arc(cx,cy,radius,startAngle,needleAngle);
        ctx.strokeStyle=getColor(avg);ctx.lineWidth=10;ctx.stroke();
        // 刻度
        for(let i=0;i<=8;i++){
            const t=i/8;
            const ang=startAngle+(endAngle-startAngle)*t;
            ctx.beginPath();
            ctx.moveTo(cx+Math.cos(ang)*(radius-14),cy+Math.sin(ang)*(radius-14));
            ctx.lineTo(cx+Math.cos(ang)*(radius-6),cy+Math.sin(ang)*(radius-6));
            ctx.strokeStyle=t<=volRatio?getColor(avg):"#555";ctx.lineWidth=2;ctx.stroke();
        }
        // 指针
        ctx.beginPath();
        ctx.moveTo(cx,cy);
        ctx.lineTo(cx+Math.cos(needleAngle)*radius*0.8,cy+Math.sin(needleAngle)*radius*0.8);
        ctx.strokeStyle=getColor(200);ctx.lineWidth=2.5;ctx.lineCap="round";ctx.stroke();
        ctx.beginPath();ctx.arc(cx,cy,6,0,Math.PI*2);
        ctx.fillStyle=getColor(180);ctx.fill();
        // 标签
        ctx.fillStyle="#999";ctx.font="12px sans-serif";ctx.textAlign="center";
        ctx.fillText(label,cx,cy+radius*0.45);
        ctx.fillStyle="#ccc";ctx.font="bold 16px monospace";
        ctx.fillText(Math.round(volRatio*100),cx,cy+radius*0.65);
    }
    drawGauge(leftCx,lowAvg,"LOW");
    drawGauge(rightCx,highAvg,"HIGH");
}

// ===== 放射横线 =====
function drawRadialLines(w,h,bufferLength,dataArray){
    const cx=w/2,cy=h/2;
    const lineCount=96;
    const baseR=Math.min(w,h)*0.12;
    for(let i=0;i<lineCount;i++){
        const idx=Math.floor(i/lineCount*bufferLength);
        let v=dataArray[idx]*sensitivity;
        if(v>255)v=255;
        const ang=(i/lineCount)*Math.PI*2;
        const len=baseR+(v/255)*Math.min(w,h)*0.35;
        const x1=cx+Math.cos(ang)*baseR;
        const y1=cy+Math.sin(ang)*baseR;
        const x2=cx+Math.cos(ang)*len;
        const y2=cy+Math.sin(ang)*len;
        ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);
        ctx.strokeStyle=getColor(v);ctx.lineWidth=2;ctx.lineCap="round";ctx.stroke();
    }
    // 中心圆
    ctx.beginPath();ctx.arc(cx,cy,baseR*0.6,0,Math.PI*2);
    ctx.fillStyle=colorWithAlpha(getColor(120),0.3);ctx.fill();
}

// ========== 9. 音量锁定（APK / Capacitor 原生桥） ==========
let isCapacitor = false;
let volumeLocked = false;

function updateVolBtnText(){
    const btn = document.getElementById("volBtn");
    if(!btn) return;
    if(volumeLocked){
        btn.textContent = L.volUnlock || "解锁音量";
        btn.classList.remove("secondary");
    }else{
        btn.textContent = L.volLock || "锁定音量";
        btn.classList.add("secondary");
    }
}

function toggleVolumeLock(){
    volumeLocked = !volumeLocked;
    updateVolBtnText();
    if(isCapacitor && window.Capacitor.Plugins.VolumeControl){
        if(volumeLocked){
            // 锁定：强制设为 100% 防止设备音量影响可视化
            window.Capacitor.Plugins.VolumeControl.setVolume({volume:1.0}).catch(function(e){
                console.error("[App] setVolume error:", e);
            });
        }
        // 解锁时不做额外操作，保持系统音量
    }
}

// 检测 Capacitor 原生环境；并按系统语言初始化界面语言
function detectNativeEnvironment(){
    try{
        isCapacitor = !!(window.Capacitor && window.Capacitor.Plugins);
    }catch(e){
        isCapacitor = false;
        console.error("[App] detect capacitor error:", e);
    }
    if(!isCapacitor) return;
    try{
        if(window.Capacitor.Plugins.Device){
            window.Capacitor.Plugins.Device.getLanguageCode().then(function(res){
                if(res && res.value){
                    const lang = String(res.value).toLowerCase();
                    let idx = 0;
                    if(lang.indexOf("zh-tw")>=0 || lang.indexOf("zh-hk")>=0){
                        idx = 1;
                    }else if(lang.indexOf("zh")>=0){
                        idx = 0;
                    }else if(lang.indexOf("ja")>=0){
                        idx = 3;
                    }else{
                        idx = 2;
                    }
                    if(idx !== currentLangIndex){
                        currentLangIndex = idx;
                        updateLocaleUI();
                    }
                }
            }).catch(function(e){ console.error("[App] getLanguageCode error:", e); });
        }
    }catch(e){
        console.error("[App] device language error:", e);
    }
}

// ========== 10. 初始化 ==========
let appBooted = false;
function bootApp(){
    if(appBooted) return;
    appBooted = true;
    try{
        initAvailableFonts();
        updateLocaleUI();
        applyBtnColor();
        applyUiTheme();
        chkBgParticle.checked = enableBgParticle;
        bgParticleDensityRow.style.display = enableBgParticle ? "block" : "none";
        initBgParticles();
        resizeCanvas();
        updateVolBtnText();
        // 挂接系统媒体监听（media-bridge.js：权限引导 / 监听开关 / 顶部信息条渲染）
        if(window.MediaBridge && typeof window.MediaBridge.init === "function"){
            window.MediaBridge.init();
        }
        // APK 原生环境：系统语言检测 + 音量锁定能力
        detectNativeEnvironment();
    }catch(e){
        console.error("[App] boot error:", e);
    }
}

// 确保 DOM 就绪后初始化（含超时兜底，防止极少数环境事件丢失）
if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", bootApp);
    setTimeout(bootApp, 3000);
}else{
    bootApp();
}
