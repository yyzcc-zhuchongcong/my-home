# Audio Spectrum — 原生侧打包对接说明

本文档面向把本项目封装为 **Android APK**（WebView 壳 / Capacitor 工程）的原生开发者，
说明「系统媒体监听」相关能力的**权限声明**、**桥接接口契约**与**联调方式**。

Web 端对应实现：`media-bridge.js`（自动检测原生桥，无桥环境自动降级、不影响其他功能）。

---

## 1. 权限声明（AndroidManifest.xml）

```xml
<!-- 媒体监听前台服务（Android 14+ 必须带 mediaPlayback 类型） -->
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK" />

<!-- Android 13+ 通知权限（POST_NOTIFICATIONS，运行时申请） -->
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />

<application>
    <!-- 媒体监听前台服务 -->
    <service
        android:name=".MediaListenerService"
        android:exported="false"
        android:foregroundServiceType="mediaPlayback" />

    <!-- 通知使用权服务（NotificationListenerService，需用户在系统设置中手动开启） -->
    <service
        android:name=".MediaNotificationListener"
        android:exported="true"
        android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">
        <intent-filter>
            <action android:name="android.service.notification.NotificationListenerService" />
        </intent-filter>
    </service>
</application>
```

> 说明：抓取其他音乐 App 的播放信息依赖 `NotificationListenerService`
> （系统「通知使用权」），该权限**无法静默获取**，必须引导用户到
> 「设置 → 通知 → 通知使用权」中手动授权；Android 13+ 还需要额外申请
> 运行时通知权限（`POST_NOTIFICATIONS`）。

---

## 2. 两种接入方式（二选一即可，Web 端自动识别）

### 方式 A：Capacitor 插件（推荐）

实现并注册插件 `MusicNotification`，Web 端通过
`window.Capacitor.Plugins.MusicNotification` 调用。

### 方式 B：原生 addJavascriptInterface

注册 JS 接口对象 `window.MusicNotificationBridge`：

```java
webView.addJavascriptInterface(new MusicNotificationBridge(this), "MusicNotificationBridge");
```

---

## 3. 接口契约（Web 端会调用的方法）

| 方法 | 参数 | 返回 | 说明 |
| --- | --- | --- | --- |
| `getCurrent()` | 无 | 媒体信息对象 / JSON 字符串 / null | 取当前播放信息（轮询与启动时调用） |
| `startListener()` | 无 | 任意 | 启动监听（拉起前台服务） |
| `stopListener()` | 无 | 任意 | 停止监听（结束前台服务） |
| `requestPermission()` | 无 | 布尔 / `"granted"` / `"denied"` | 【Capacitor 分支】申请通知权限，可同步返回 |
| `requestNotificationPermission()` | 无 | 无 | 【Android 分支】发起通知权限申请，结果见第 5 节回调 |
| `hasNotificationPermission()` | 无 | 布尔 / `"true"` / `"false"` | 查询通知权限现状 |
| `getPermissionStatus()` | 无 | `{ granted?, notifications?, listenerEnabled? }` | 查询权限与监听状态（各字段可缺省） |
| `isListenerEnabled()` | 无 | 布尔 / `"true"` / `"false"` | 查询「通知使用权」是否已授权 |
| `openSettings()` | 无 | 任意 | 打开系统「通知使用权」设置页 |

**兼容性要求**：所有方法需支持**同步返回值**与 **Promise / 回调**两种形态之一；
Web 端对返回值做了容错归一化（布尔、字符串、对象均可识别），异常会被安全吞掉。

### 媒体信息对象字段

```json
{
  "title": "歌曲名",
  "artist": "歌手",
  "album": "专辑",
  "appName": "来源应用",
  "isPlaying": true
}
```

字段别名兼容：`track`/`song`/`name`（曲名）、`artists`/`subtitle`/`text`（歌手）、
`subText`（专辑）、`application`/`packageName`/`source`（来源应用）、
`playing`/`state`（播放状态：`playing`/`paused`/`stopped`）。

---

## 4. 推荐实现要点

1. **前台服务**：`startListener()` 中 `startForeground()` 并展示常驻通知
   （Android 14+ 需声明 `mediaPlayback` 类型；`stopListener()` 调用
   `stopForeground()` + `stopSelf()`）。
2. **信息采集**：优先从 `MediaSessionManager.getActiveSessions()` 的
   `MediaController.getMetadata()` 读取 `TITLE` / `ARTIST` / `ALBUM`，
   并用 `getPlaybackState()` 判断播放状态；低版本降级解析通知标题栏。
3. **缓存最近信息**：`getCurrent()` 返回缓存值，避免轮询时阻塞主线程。
4. **权限细则**：
   - Android 13+：`requestNotificationPermission()` 调用
     `ActivityCompat.requestPermissions(...)`，结果经第 5 节回调回传；
   - 「通知使用权」：通过
     `Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS` 跳转授权页，
     授权完成后 `isListenerEnabled()` 应能返回 `true`。

---

## 5. 原生 → Web 的事件推送（任选，Web 端均已监听）

```js
// 1) 通用函数调用（推荐，兼容旧版）
window.updateMusicInfo("歌曲名", "歌手", "专辑", "来源应用", true);
window.updateMusicInfo({ title, artist, album, appName, isPlaying }); // 对象形式

// 2) 专用入口（JSON 字符串或对象均可）
window.onMusicInfoUpdate("{\"title\":\"...\",\"artist\":\"...\",\"isPlaying\":true}");

// 3) 事件派发
window.dispatchEvent(new CustomEvent("musicInfo", { detail: {...} }));
window.dispatchEvent(new CustomEvent("musicState", { detail: {...} }));

// 4) 通知权限申请结果回调（Android 分支必接）
window.onMediaNotificationPermissionResult(true); // 或 false
```

> 建议：`MediaNotificationListener.onNotificationPosted()` 中节流后
> 通过 `webView.post(() -> webView.evaluateJavascript(...))` 推送，避免高频刷新。

---

## 6. 联调自检清单

- [ ] 未打包 APK（纯浏览器）时：设置面板显示「这个环境用不了，打包成 APK 后才能用哦」，且不影响其他功能；
- [ ] APK 内首次启动：延迟弹出「开启系统媒体信息」权限说明弹窗，点「允许」走系统授权流程；
- [ ] 开启监听后切到音乐 App 播放：顶部歌名栏自动更新（歌名 / 歌手 · 来源应用），播放/暂停图标状态变化；
- [ ] 失败路径：拒绝通知权限 → 状态栏提示「建议允许通知权限」，情境按钮变为「允许通知」；
- [ ] 未授权通知使用权 → 状态提示「还差一步：去系统设置里开启『通知使用权』」，按钮变为「去开启」；
- [ ] 关闭监听开关 → 前台服务停止，顶部信息条恢复「—」。

---

## 7. 调试入口

Web 控制台可执行 `window.MediaBridge.getState()` 查看当前桥接模式与状态：

```js
{
  bridgeMode: "capacitor" | "android" | "none",
  enabled: false,          // 监听开关
  permGranted: null,       // 通知权限 true/false/null
  listenerAccess: null,    // 通知使用权 true/false/null
  lastInfo: null           // 最近一次媒体信息
}
```
