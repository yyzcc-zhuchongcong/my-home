/* ============================================================
   locales.js — 多语言字典（简体中文 / 繁體中文 / English / 日本語）
   说明：volUnlock 之后为「系统媒体监听」新增文案，供 media-bridge.js 使用
   ============================================================ */

const locales = {
    "zh-CN":{
        tip:"放歌开大声点，记得让我用麦克风哦",
        btnStart:"开启音频频谱",
        btnRunning:"频谱运行中，点我停止",
        btnStop:"停止频谱",
        btnSettings:"设置",
        btnClose:"关闭",
        btnFontHelp:"添加字体",
        btnFontRec:"推荐字体",
        fontRecTitle:"推荐字体",
        fontRecSub:"点一下就能用，没装的点整行去添加字体",
        fontRecAvail:"已装好了",
        fontRecMissing:"还没装",
        fontRecApply:"用这个",
        fontRecInstall:"去装",
        volLock:"锁定音量",
        volUnlock:"解锁音量",
        labMediaListen:"系统媒体监听",
        mediaStatusOff:"已关闭：打开后，歌名栏会跟着系统和其他应用播放的音乐自动切换",
        mediaStatusWait:"正在监听，去系统里放首歌试试",
        mediaStatusLive:"正在同步系统媒体播放信息",
        mediaStatusNoBridge:"这个环境用不了，打包成 APK 后才能用哦",
        mediaStatusNoPerm:"建议允许通知权限，同步更稳定",
        mediaStatusNoAccess:"还差一步：去系统设置里开启「通知使用权」",
        btnMediaPerm:"允许通知",
        btnMediaOpenSettings:"去开启",
        permTitle:"开启系统媒体信息",
        permBody:`<p>打开后，顶部的歌名栏会跟着系统播放器、以及其他音乐应用正在播放的歌曲自动变化。</p><p><strong>Android 13 及以上</strong>需要“通知”权限，下一步系统会弹窗询问，点「允许」就行。</p><p>我们只读取歌名、歌手和来源应用，不读别的东西。</p>`,
        permAllow:"允许",
        permLater:"先不用",
        toastMediaOn:"系统媒体监听开了，放首歌试试吧",
        toastMediaOff:"系统媒体监听关了",
        toastMediaUnsupported:"这个环境用不了，打包成 APK 就有效果了",
        toastPermGranted:"通知权限拿到了，媒体信息会自动同步",
        toastPermDenied:"没拿到通知权限，以后想试的话去系统设置里开一下",
        toastSettingsFail:"没能打开系统设置，要手动去开一下「通知使用权」哦",
        songNone:"暂无播放",
        songHint:"去放首歌试试",
        labStyle:"频谱风格",
        labColor:"配色方案",
        labUiStyle:"界面风格",
        labBtnColor:"按钮颜色",
        labFftSize:"频谱精度(FFT)",
        labFont:"界面字体",
        labBgParticle:"背景漂浮粒子",
        labBgDensity:"粒子密度",
        bgDensityList:["稀稀拉拉","刚刚好","密密麻麻","超级多"],
        labLang:"语言",
        labSen:"灵敏度",
        labSmooth:"平滑度",
        uiStyleList:[
            "拟物化","扁平化","玻璃质感","霓虹发光","胶囊圆角","描边线条",
            "金属质感","渐变炫彩","复古像素","3D凸起","水墨风格","赛博朋克"
        ],
        fontNames:{
            "system":"系统默认",
            "youmeng":"有梦体",
            "lxgw":"霞鹜文楷",
            "sourceHanSerif":"思源宋体",
            "yuanmo":"荆南缘默体",
            "tiejili":"铁蒺藜体",
            "zhenkai":"霞鹜臻楷",
            "jiexing":"江城解星体",
            "xinhuo":"中华薪火体",
            "huiji":"汇迹正楷",
            "hanchan":"寒蝉拙楷",
            "shanwei":"扇尾胄黑 16"
        },
        styleList:[
            "像素方格","双向柱状","环形圆环","点线波形","底部柱状",
            "镜像波浪","螺旋频谱","垂直雨线","圆形点阵","横线堆叠",
            "密集横线","模拟指针","双针表盘","放射横线"
        ],
        colorList:[
            "彩虹","冰蓝","洋红","暗夜绿","单色白",
            "霓虹紫","赛博青","落日橙","冷银灰","薄荷",
            "血红色","深空蓝","樱花粉","金黄","青柠绿",
            "珊瑚橙","薰衣草紫","翡翠绿"
        ],
        btnColorList:["蓝色","红色","绿色","紫色","橙色","暗黑","粉色","青色","金黄","纯白"],
        fftSizeList:[256,512,1024,2048,4096,8192],
        langNames:["简体中文","繁體中文","English","日本語"],
        fontModal:{
            title:"添加字体文件",
            content:`
<p>网页没法自动拿到你电脑里的字体，得你自己选字体文件装进来才能用哦。</p>
<p>点下面的按钮，从电脑里挑字体文件（TTF / OTF / WOFF / WOFF2，可以一次选好几个）装进来。</p>
<hr class="font-divider">
<p><strong>在下面添加字体：</strong></p>
<label class="add-font-btn" for="modalFontFile">点我手动装字体</label>
<input type="file" id="modalFontFile" accept=".ttf,.otf,.woff,.woff2" multiple style="display:none">
<p class="font-feedback" id="fontFeedback"></p>
`
        },
        fontAddOk:"装好了 {n} 个字体，切过去就能用",
        fontAddFail:"{n} 个文件没装上，看看格式对不对",
        micFail:"麦克风用不了：{err}\n记得让我用麦克风呀！"
    },
    "zh-TW":{
        tip:"放音樂記得開大聲一點，然後讓我用麥克風喔",
        btnStart:"開啟音頻頻譜",
        btnRunning:"頻譜執行中，點我停止",
        btnStop:"停止頻譜",
        btnSettings:"設定",
        btnClose:"關閉",
        btnFontHelp:"新增字體",
        btnFontRec:"推薦字體",
        fontRecTitle:"推薦字體",
        fontRecSub:"點一下就能用，沒裝的點整行去新增字體",
        fontRecAvail:"已經裝好了",
        fontRecMissing:"還沒裝",
        fontRecApply:"用這個",
        fontRecInstall:"去裝",
        volLock:"鎖定音量",
        volUnlock:"解鎖音量",
        labMediaListen:"系統媒體監聽",
        mediaStatusOff:"已關閉：打開後，歌名欄會跟著系統和其他應用播放的音樂自動切換",
        mediaStatusWait:"正在監聽，去系統裡放首歌試試",
        mediaStatusLive:"正在同步系統媒體播放資訊",
        mediaStatusNoBridge:"這個環境用不了，打包成 APK 後才能用喔",
        mediaStatusNoPerm:"建議允許通知權限，同步更穩定",
        mediaStatusNoAccess:"還差一步：去系統設定裡開啟「通知存取權」",
        btnMediaPerm:"允許通知",
        btnMediaOpenSettings:"去開啟",
        permTitle:"開啟系統媒體資訊",
        permBody:`<p>打開後，頂部的歌名欄會跟著系統播放器、以及其他音樂應用正在播放的歌曲自動變化。</p><p><strong>Android 13 以上</strong>需要「通知」權限，下一步系統會跳窗詢問，點「允許」就好。</p><p>我們只讀取歌名、歌手和來源應用，不讀其他東西。</p>`,
        permAllow:"允許",
        permLater:"先不用",
        toastMediaOn:"系統媒體監聽開了，放首歌試試吧",
        toastMediaOff:"系統媒體監聽關了",
        toastMediaUnsupported:"這個環境用不了，打包成 APK 就有效果了",
        toastPermGranted:"通知權限拿到了，媒體資訊會自動同步",
        toastPermDenied:"沒拿到通知權限，以後想試的話去系統設定裡開一下",
        toastSettingsFail:"沒能開啟系統設定，要手動去開一下「通知存取權」喔",
        songNone:"暫無播放",
        songHint:"去放首歌試試",
        labStyle:"頻譜風格",
        labColor:"配色方案",
        labUiStyle:"介面風格",
        labBtnColor:"按鈕顏色",
        labFftSize:"頻譜精度(FFT)",
        labFont:"介面字體",
        labBgParticle:"背景漂浮粒子",
        labBgDensity:"粒子密度",
        bgDensityList:["稀稀落落","剛剛好","密密麻麻","超級多"],
        labLang:"語言",
        labSen:"靈敏度",
        labSmooth:"平滑度",
        uiStyleList:[
            "擬物化","扁平化","玻璃質感","霓虹發光","膠囊圓角","描邊線條",
            "金屬質感","漸層炫彩","復古像素","3D立體","水墨風格","賽博龐克"
        ],
        fontNames:{
            "system":"系統預設",
            "youmeng":"有夢體",
            "lxgw":"霞鶩文楷",
            "sourceHanSerif":"思源宋體",
            "yuanmo":"荊南緣默體",
            "tiejili":"鐵蒺藜體",
            "zhenkai":"霞鶩臻楷",
            "jiexing":"江城解星體",
            "xinhuo":"中華薪火體",
            "huiji":"匯跡正楷",
            "hanchan":"寒蟬拙楷",
            "shanwei":"扇尾冑黑 16"
        },
        styleList:[
            "像素方格","雙向柱狀","環形圓環","點線波形","底部柱狀",
            "鏡像波浪","螺旋頻譜","垂直雨線","圓形點陣","橫線堆疊",
            "密集橫線","模擬指針","雙針錶盤","放射橫線"
        ],
        colorList:[
            "彩虹","冰藍","洋紅","暗夜綠","單色白",
            "霓虹紫","賽博青","落日橙","冷銀灰","薄荷",
            "血紅色","深空藍","櫻花粉","金黃","青檸綠",
            "珊瑚橙","薰衣草紫","翡翠綠"
        ],
        btnColorList:["藍色","紅色","綠色","紫色","橙色","暗黑","粉色","青色","金黃","純白"],
        fftSizeList:[256,512,1024,2048,4096,8192],
        langNames:["簡體中文","繁體中文","English","日本語"],
        fontModal:{
            title:"新增字體檔案",
            content:`
<p>網頁沒辦法自動拿到你電腦裡的字體，得你自己選字體檔案裝進來才能用喔。</p>
<p>點下面的按鈕，從電腦裡挑字體檔案（TTF / OTF / WOFF / WOFF2，可以一次選好幾個）裝進來。</p>
<hr class="font-divider">
<p><strong>在下面新增字體：</strong></p>
<label class="add-font-btn" for="modalFontFile">點我手動裝字體</label>
<input type="file" id="modalFontFile" accept=".ttf,.otf,.woff,.woff2" multiple style="display:none">
<p class="font-feedback" id="fontFeedback"></p>
`
        },
        fontAddOk:"裝好了 {n} 個字體，切過去就能用",
        fontAddFail:"{n} 個檔案沒裝上，看看格式對不對",
        micFail:"麥克風用不了：{err}\n記得讓我用麥克風呀！"
    },
    "en":{
        tip:"Crank up the music and let me use your mic",
        btnStart:"Start Spectrum",
        btnRunning:"Running — tap to stop",
        btnStop:"Stop Spectrum",
        btnSettings:"Settings",
        btnClose:"Close",
        btnFontHelp:"Add Fonts",
        btnFontRec:"Recommend Fonts",
        fontRecTitle:"Recommended Fonts",
        fontRecSub:"Tap to use — tap a missing font to add it",
        fontRecAvail:"Installed",
        fontRecMissing:"Not installed",
        fontRecApply:"Use",
        fontRecInstall:"Install",
        volLock:"Lock Volume",
        volUnlock:"Unlock Volume",
        labMediaListen:"System media listening",
        mediaStatusOff:"Off — when on, the song bar follows whatever the system and other apps play",
        mediaStatusWait:"Listening — go play something in the system",
        mediaStatusLive:"Syncing system media info",
        mediaStatusNoBridge:"Not available here — it works in the packaged APK",
        mediaStatusNoPerm:"Allow notifications for steadier syncing",
        mediaStatusNoAccess:"One more step: enable “Notification access” in system settings",
        btnMediaPerm:"Allow notifications",
        btnMediaOpenSettings:"Open",
        permTitle:"Enable System Media Info",
        permBody:`<p>Once on, the top song bar follows what your system player and other music apps are playing.</p><p><strong>Android 13+</strong> needs the Notifications permission — the system will ask next, just tap “Allow”.</p><p>We only read the song title, artist and source app. Nothing else.</p>`,
        permAllow:"Allow",
        permLater:"Not now",
        toastMediaOn:"Media listening is on — play a song",
        toastMediaOff:"Media listening is off",
        toastMediaUnsupported:"Not available here — it works once packaged as an APK",
        toastPermGranted:"Notifications allowed — media info will sync automatically",
        toastPermDenied:"No notification permission — you can enable it later in system settings",
        toastSettingsFail:"Couldn't open system settings — please enable “Notification access” manually",
        songNone:"Nothing playing",
        songHint:"Go play a song",
        labStyle:"Spectrum Style",
        labColor:"Color Theme",
        labUiStyle:"UI Style",
        labBtnColor:"Button Color",
        labFftSize:"Spectrum FFT",
        labFont:"UI Font",
        labBgParticle:"Floating bg particles",
        labBgDensity:"Particle density",
        bgDensityList:["Sparse","Just right","Dense","Super dense"],
        labLang:"Language",
        labSen:"Sensitivity",
        labSmooth:"Smooth",
        uiStyleList:[
            "Skeuomorphic","Flat","Glass","Neon Glow","Pill","Outline",
            "Metal","Gradient","Retro Pixel","3D Pop","Ink Wash","Cyberpunk"
        ],
        fontNames:{
            "system":"System Default",
            "youmeng":"YouMeng Ti",
            "lxgw":"LXGW WenKai",
            "sourceHanSerif":"Source Han Serif",
            "yuanmo":"JingNan YuanMo",
            "tiejili":"TieJiLi Ti",
            "zhenkai":"LXGW ZhenKai",
            "jiexing":"JiangCheng JieXing",
            "xinhuo":"ZhongHua XinHuo",
            "huiji":"HuiJi ZhengKai",
            "hanchan":"HanChan ZhuoKai",
            "shanwei":"ShanWei ZhouHei 16"
        },
        styleList:[
            "Pixel Grid","Dual Bar","Ring","Dot Line Wave","Bottom Bar",
            "Mirror Wave","Spiral","Rain Line","Circle Dot","Horizontal Stack",
            "Dense Lines","Analog Needle","Dual Needle","Radial Lines"
        ],
        colorList:[
            "Rainbow","Ice Blue","Magenta","Dark Green","Mono White",
            "Neon Purple","Cyber Cyan","Sunset Orange","Silver Gray","Mint",
            "Blood Red","Deep Space Blue","Sakura Pink","Golden","Lime Green",
            "Coral Orange","Lavender Purple","Emerald Green"
        ],
        btnColorList:["Blue","Red","Green","Purple","Orange","Dark","Pink","Cyan","Gold","White"],
        fftSizeList:[256,512,1024,2048,4096,8192],
        langNames:["Simplified Chinese","Traditional Chinese","English","Japanese"],
        fontModal:{
            title:"Add Font Files",
            content:`
<p>The page can't grab fonts from your computer automatically — you need to pick font files and load them in.</p>
<p>Tap the button below and choose font files (TTF / OTF / WOFF / WOFF2, multiple OK) to load.</p>
<hr class="font-divider">
<p><strong>Add fonts below:</strong></p>
<label class="add-font-btn" for="modalFontFile">Tap to load a font</label>
<input type="file" id="modalFontFile" accept=".ttf,.otf,.woff,.woff2" multiple style="display:none">
<p class="font-feedback" id="fontFeedback"></p>
`
        },
        fontAddOk:"{n} font(s) loaded. Switch to use them.",
        fontAddFail:"{n} file(s) failed to load. Check the format.",
        micFail:"Mic access failed: {err}\nPlease allow microphone access!"
    },
    "ja":{
        tip:"音楽を大きめにかけて、マイクを使わせてね",
        btnStart:"スペクトラム開始",
        btnRunning:"動作中、タップで停止",
        btnStop:"スペクトラム停止",
        btnSettings:"設定",
        btnClose:"閉じる",
        btnFontHelp:"フォント追加",
        btnFontRec:"おすすめフォント",
        fontRecTitle:"おすすめフォント",
        fontRecSub:"タップで使えるよ。入ってないのは行ごとタップで追加画面へ",
        fontRecAvail:"インストール済み",
        fontRecMissing:"未インストール",
        fontRecApply:"使う",
        fontRecInstall:"インストール",
        volLock:"音量ロック",
        volUnlock:"ロック解除",
        labMediaListen:"システムメディア連携",
        mediaStatusOff:"オフ：オンにすると曲名バーがシステムや他アプリの再生に合わせて変わります",
        mediaStatusWait:"監視中。システムで曲を再生してみてください",
        mediaStatusLive:"システムメディア情報を同期中",
        mediaStatusNoBridge:"この環境では使えません。APKにすると使えます",
        mediaStatusNoPerm:"通知を許可すると同期が安定します",
        mediaStatusNoAccess:"あと一歩：「通知へのアクセス」をシステム設定で有効に",
        btnMediaPerm:"通知を許可",
        btnMediaOpenSettings:"開く",
        permTitle:"システムメディア情報をオン",
        permBody:`<p>オンにすると、上部の曲名バーがシステムプレイヤーや他の音楽アプリの再生に合わせて変わります。</p><p><strong>Android 13 以上</strong>では「通知」権限が必要です。次にシステムが確認するので「許可」を押してください。</p><p>読み取るのは曲名・アーティスト・再生アプリのみです。</p>`,
        permAllow:"許可",
        permLater:"あとで",
        toastMediaOn:"システムメディア連携をオンにしました。曲を再生してみてください",
        toastMediaOff:"システムメディア連携をオフにしました",
        toastMediaUnsupported:"この環境では使えません。APKにすると効果があります",
        toastPermGranted:"通知が許可されました。メディア情報が自動で同期されます",
        toastPermDenied:"通知権限がありません。システム設定から後で有効にできます",
        toastSettingsFail:"システム設定を開けませんでした。「通知へのアクセス」を手動で有効にしてください",
        songNone:"再生なし",
        songHint:"曲を再生してみて",
        labStyle:"スペクトラムスタイル",
        labColor:"カラーテーマ",
        labUiStyle:"UIスタイル",
        labBtnColor:"ボタン色",
        labFftSize:"FFTサイズ",
        labFont:"UIフォント",
        labBgParticle:"背景漂う粒子",
        labBgDensity:"粒子密度",
        bgDensityList:["少なめ","ちょうどいい","多め","超多い"],
        labLang:"言語",
        labSen:"感度",
        labSmooth:"スムーズ",
        uiStyleList:[
            "擬物風","フラット","ガラス","ネオン","ピル型","アウトライン",
            "メタル","グラデーション","レトロピクセル","3Dポップ","水墨風","サイバーパンク"
        ],
        fontNames:{
            "system":"システム標準",
            "youmeng":"有夢体（ゆうむたい）",
            "lxgw":"霞鶩文楷（かこぶんかい）",
            "sourceHanSerif":"思源宋体（しげんそうたい）",
            "yuanmo":"荊南縁默体（けいなんえんもくたい）",
            "tiejili":"鉄蒺藜体（てつしつりたい）",
            "zhenkai":"霞鶩臻楷（かこしんかい）",
            "jiexing":"江城解星体（こうじょうかいせいたい）",
            "xinhuo":"中華薪火体（ちゅうかしんかたい）",
            "huiji":"匯跡正楷（あいせきせいかい）",
            "hanchan":"寒蟬拙楷（かんせんせっかい）",
            "shanwei":"扇尾冑黒16（せんびちゅうこく16）"
        },
        styleList:[
            "ピクセルグリッド","双方向バー","リング","ドット波","下部バー",
            "ミラー波","スパイラル","雨ライン","円ドット","横線スタック",
            "密集横線","アナログ針","デュアル針ゲージ","放射線"
        ],
        colorList:[
            "レインボー","アイスブルー","マゼンタ","ダークグリーン","単色白",
            "ネオンパープル","サイバーシアン","サンセットオレンジ","シルバーグレー","ミント",
            "ブラッドレッド","ディープブルー","桜ピンク","ゴールド","ライムグリーン",
            "コーラルオレンジ","ラベンダーパープル","エメラルドグリーン"
        ],
        btnColorList:["青","赤","緑","紫","オレンジ","黒","ピンク","シアン","ゴールド","白"],
        fftSizeList:[256,512,1024,2048,4096,8192],
        langNames:["簡体字中国語","繁体字中国語","English","日本語"],
        fontModal:{
            title:"フォントファイルを追加",
            content:`
<p>ウェブページはパソコンのフォントを自動で取れません。自分でフォントファイルを選んで読み込む必要があります。</p>
<p>下のボタンから、ローカルのフォントファイル（TTF / OTF / WOFF / WOFF2、複数可）を選んで読み込んでください。</p>
<hr class="font-divider">
<p><strong>ここより下にフォントを追加：</strong></p>
<label class="add-font-btn" for="modalFontFile">タップしてフォントを読み込む</label>
<input type="file" id="modalFontFile" accept=".ttf,.otf,.woff,.woff2" multiple style="display:none">
<p class="font-feedback" id="fontFeedback"></p>
`
        },
        fontAddOk:"{n} 個のフォントを追加しました。切り替えて使えます。",
        fontAddFail:"{n} 個のファイルが読み込めませんでした。形式を確認してください。",
        micFail:"マイクの権限が拒否されました：{err}\nマイクの許可を与えてください！"
    }
};
